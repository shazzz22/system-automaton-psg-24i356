import csv
import random

# Number of readings to generate
NUM_READINGS = 250

# Output CSV file
filename = "sensor_readings.csv" 

# Generate random sensor readings
with open(filename, mode="w", newline="") as file:
    writer = csv.writer(file)

    # CSV column headers
    writer.writerow([
        "temperature",
        "pressure",
        "rpm",
        "current",
        "state",
        "vibration"
    ])

    for _ in range(NUM_READINGS):
        temperature = round(random.uniform(20, 100), 2)
        pressure = round(random.uniform(1, 10), 2)
        rpm = random.randint(500, 3000)
        current = round(random.uniform(1, 20), 2)
        state = random.choice(["Running", "Idle", "Fault"])
        vibration = round(random.uniform(0.1, 10), 2)

        writer.writerow([
            temperature,
            pressure,
            rpm,
            current,
            state,
            vibration
        ])

print(f"Successfully generated {NUM_READINGS} readings.")
print(f"CSV file saved as: {filename}")